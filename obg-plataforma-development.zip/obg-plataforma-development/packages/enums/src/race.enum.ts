

export enum RaceEnum {
  WHITE = 'WHITE',
  BLACK = 'BLACK',
  BROWN = 'BROWN',
  YELLOW = 'YELLOW',
  INDIGENOUS = 'INDIGENOUS'
}