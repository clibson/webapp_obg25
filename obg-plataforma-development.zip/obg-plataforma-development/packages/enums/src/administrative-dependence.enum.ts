export enum AdministrativeDependencies {
  'Federal' = 'Federal',
  'Estadual' = 'Estadual',
  'Municipal' = 'Municipal',
  'Privada' = 'Privada',
}
