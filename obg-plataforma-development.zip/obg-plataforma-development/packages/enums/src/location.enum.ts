export enum Location {
  'Urbana' = 'Urbana',
  'Rural' = 'Rural',
}
