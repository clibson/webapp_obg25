

export enum LevelOfEducationEnum {
  EF9 = 'EF9',
  EM1 = 'EM1',
  EM2 = 'EM2',
  EM3 = 'EM3',
}