export enum Administrativecategory {
  'Pública' = 'Pública',
  'Privada' = 'Privada',
}
