export enum Privatecategory {
  'Não Informado' = 'Não Informado',
  'Comunitária' = 'Comunitária',
  'Confessional' = 'Confessional',
  'Filantrópica' = 'Filantrópica',
  'Particular' = 'Particular',
}
