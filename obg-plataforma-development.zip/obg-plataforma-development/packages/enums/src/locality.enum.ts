export enum Locality {
  'A escola não está em área de localização diferenciada' = 'A escola não está em área de localização diferenciada',
  'Não Informado' = 'Não Informado',
  'Terra indígena' = 'Terra indígena',
  'Área de assentamento' = 'Área de assentamento',
  'Área onde se localizam povos e comunidades tradicionais' = 'Área onde se localizam povos e comunidades tradicionais',
  'Área remanescente de quilombos' = 'Área remanescente de quilombos',
}
